package com.instaguard.app

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val igColors = intArrayOf(0xFFF58529.toInt(), 0xFFDD2A7B.toInt(), 0xFF8134AF.toInt())

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(':').any { it.startsWith("$packageName/") && it.endsWith("GuardService") }
    }

    private fun render() {
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bg = if (dark) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        val fg = if (dark) 0xFFF5F5F5.toInt() else 0xFF262626.toInt()
        val sub = if (dark) 0xFFA8A8A8.toInt() else 0xFF737373.toInt()
        val card = if (dark) 0xFF121212.toInt() else 0xFFF4F4F4.toInt()
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(44), dp(22), dp(32))
        }

        fun text(s: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0) = TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(top), 0, 0)
        }

        fun button(label: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
            text = label
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setTextColor(if (filled) 0xFFFFFFFF.toInt() else fg)
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                if (filled) {
                    orientation = GradientDrawable.Orientation.LEFT_RIGHT
                    colors = igColors
                } else {
                    setColor(card)
                }
            }
            setOnClickListener { onClick() }
        }

        fun gap(h: Int) = View(this).apply { minimumHeight = dp(h) }

        // Title with Instagram gradient
        val title = text("InstaGuard", 34f, fg, true)
        title.paint.shader = LinearGradient(0f, 0f, title.paint.measureText("InstaGuard"), 0f, igColors, null, Shader.TileMode.CLAMP)
        root.addView(title)
        root.addView(text("Instagram, minus the endless scroll.", 15f, sub))
        root.addView(gap(18))

        // Status
        val on = serviceOn()
        root.addView(text(
            if (on) "Service is ON. It sleeps while Instagram is closed and wakes by itself when you open it."
            else "Service is OFF. Follow the two steps below.",
            14f, if (on) 0xFF2ECC71.toInt() else 0xFFED4956.toInt(), true))
        root.addView(gap(18))

        root.addView(text("Setup (3 steps)", 18f, fg, true))
        root.addView(text("1. Android 13+ blocks accessibility for apps installed from a file. Open App info, tap the three dots (top right) and choose \"Allow restricted settings\".", 13f, sub, false, 8))
        root.addView(gap(8))
        root.addView(button("Open App info", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        root.addView(text("2. Open Accessibility settings, find InstaGuard (Installed / Downloaded apps) and switch it on.", 13f, sub, false, 14))
        root.addView(gap(8))
        root.addView(button("Open Accessibility settings", true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(text("3. Allow \"Display over other apps\". With this ON, phone screens (notification shade, volume bar, screenshot preview, navigation buttons) stay on top of the cover and keep working. " +
            if (Settings.canDrawOverlays(this)) "Status: allowed." else "Status: NOT allowed yet.", 13f, sub, false, 14))
        root.addView(gap(8))
        root.addView(button("Allow display over other apps", !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(gap(22))

        // Controls
        root.addView(text("Controls", 18f, fg, true))
        root.addView(Switch(this).apply {
            text = "Guard active"
            setTextColor(fg)
            isChecked = Prefs.enabled(this@MainActivity)
            setPadding(0, dp(12), 0, dp(12))
            setOnCheckedChangeListener { _, c -> Prefs.setEnabled(this@MainActivity, c) }
        })

        root.addView(text("Cover colours", 13f, sub))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("Phone", "Light", "Dark")
        val cur = Prefs.theme(this)
        names.forEachIndexed { i, n ->
            val b = button(n, i == cur) { Prefs.setTheme(this, i); render() }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
        root.addView(gap(6))
        root.addView(row)

        root.addView(text("Dark cover shade", 13f, sub, false, 14))
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val curShade = Prefs.darkShade(this)
        listOf("Navy (new Instagram)", "Black (old)").forEachIndexed { i, n ->
            val b = button(n, i == curShade) { Prefs.setDarkShade(this, i); render() }
            row2.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
        root.addView(gap(6))
        root.addView(row2)

        root.addView(Switch(this).apply {
            text = "Debug bubble (shows detected screen, tap to copy IDs)"
            setTextColor(fg)
            isChecked = Prefs.debug(this@MainActivity)
            setPadding(0, dp(18), 0, dp(12))
            setOnCheckedChangeListener { _, c -> Prefs.setDebug(this@MainActivity, c) }
        })

        root.addView(gap(10))
        root.addView(text(
            "Battery: nothing runs while Instagram is closed or the screen is off. No timers, no wake locks, no background service of its own.",
            12f, sub))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        })
    }
}
