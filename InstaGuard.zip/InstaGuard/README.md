# InstaGuard

Android overlay that keeps Instagram to stories, chats, camera and your own profile.
Cover = Instagram-style endless loading skeleton (dark/light).

## Build on your phone (GitHub Actions)
1. Make a GitHub repo.
2. Chrome > turn on "Desktop site" > repo > Add file > Upload files > pick InstaGuard.zip > Commit.
3. Add file > Create new file > name it  .github/workflows/build.yml  > paste the workflow > Commit.
4. Actions tab > wait for the green tick (about 5 min).
5. Code tab > Releases > latest build > download InstaGuard.apk > install.
6. Open InstaGuard and follow the three setup steps (restricted settings, accessibility, display over other apps).

## Files
- .github/workflows/build.yml  - builds the APK (unpacks the zip first if needed)
- settings.gradle.kts, build.gradle.kts, gradle.properties, app/build.gradle.kts - build config
- app/src/main/AndroidManifest.xml - app + accessibility service declaration
- res/xml/accessibility_service_config.xml - idle config: only listens for Instagram opening
- Sel.kt - Instagram view IDs (edit here if an Instagram update breaks detection)
- GuardService.kt - open/close detection, screen analysis, overlay windows
- OverlayView.kt - skeleton drawing + touch absorbing
- MainActivity.kt, Prefs.kt - setup screen and settings

## Updating
Upload the new InstaGuard.zip to the repo (same name replaces the old one), wait for the build,
uninstall the old InstaGuard from the phone, then install the new APK and redo the setup steps.
